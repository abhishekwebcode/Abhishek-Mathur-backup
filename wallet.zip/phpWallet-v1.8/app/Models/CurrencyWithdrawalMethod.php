<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CurrencyWithdrawalMethod extends Model
{
	protected $table = "currency_withdrawal_methods";	
}