<?php

namespace App\Http\Controllers;

use Auth;
use Mail;
use App\User;
use App\Models\Wallet;
use App\Models\Currency;
use Illuminate\Http\Request;
use App\Mail\verifyEmail;

class SignUpController extends Controller
{

	public function register(Request $request){
        
        
		$currency = Currency::first();

		$this->validate($request, [
            'email' => 'required|unique:users,email|email|max:255',
            'name'  =>  'required|unique:users,name|alpha_dash|min:5',
            'password'  =>  'required|min:6',
            'password_confirmation'	=>	'required|same:password',
            'terms' => 'required'
        ]);

       

        $user = User::create([
            'name'  => $request->name,
            'email' =>  $request->email,
            'password'  =>  bcrypt($request->password),
            'currency_id'	=>	 $currency->id,
            'settings'  => str_random(40),
        ]);

        
        
        //Mail::send(new VerifyEmail($user));

        if ($user) {
        	wallet::create([
        		'user_id'	=> $user->id,
        		'amount'	=>	0,
        		'currency_id'	=> $currency->id
        	]);
        }

        if (Auth::attempt(['email' => $request->email, 'password' => $request->password])) {
            Mail::send(new VerifyEmail($user));
            return redirect('/');
        }

        return redirect('/');
	}

    public function verifyEmail(Request $request, $email, $token){
        
        if ($email) {
           
           $user = User::where('email', $email)->where('verified', 0)->first();

           if (!is_null($user) and $user->settings == $token) {
               
                $user->verified = 1;
                $user->settings = NULL;
                $user->save();
           }

           return redirect('/');
        }
    }

    public function resendActivactionLink(Request $request){
        
        $string = str_random(40);
        
        $user = Auth::user();
        $user->settings = $string;
        $user->save();

        Mail::send(new VerifyEmail($user));

        flash('activation link succesfuly sent', 'success');

       return back();

    }


}