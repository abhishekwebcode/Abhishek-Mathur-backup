 <div class="col-md-3">
    <div class="card mb-3 bg-dark text-white">
        <div class="card-header"><h4>Balance</h4></div>

        <div class="card-body">
            <h5>{{__('Available')}} <span class="text-primary"> {{ Auth::user()->currentCurrency()->name }} </span></h5>
            <h1>{{ \App\Helpers\Money::instance()->value(Auth::user()->balance(), Auth::user()->currentCurrency()->symbol) }}</h1>
        </div>
        <div class="card-footer">
            <div class="btn-group btn-group-justified d-flex" role="group" aria-label="...">
                <a class="btn btn-outline-light w-100" href="{{route('withdrawal.form')}}">{{__('Withdrawal')}}</a>
                <a class="btn btn-outline-light w-100" href="{{route('add.credit')}}">{{__('Add Credit')}}</a>
            </div>
        </div>
    </div>
    @if(!Route::is('exchange.form'))
    <div class="list-group">
        {{--
        <a href="{{ route('home') }}" class="list-group-item list-group-item-action {{ (Route::is('home') ? 'active' : '') }}">Transactions</a>
        <a href="{{url('/')}}/exchange/first/0/second/0"  class="list-group-item list-group-item-action  {{ (Route::is('exchange.form') ? 'active' : '') }}">Exchange</a>
        <a href="{{route('sendMoneyForm')}}" class="list-group-item list-group-item-action {{ (Route::is('sendMoneyForm') ? 'active' : '') }}">Send Money</a>
        <a href="{{route('mydeposits')}}"  class="list-group-item list-group-item-action {{ (Route::is('mydeposits') ? 'active' : '') }}">Deposits</a>
        <a href="{{route('withdrawal.index')}}"  class="list-group-item list-group-item-action  {{ (Route::is('withdrawal.index') ? 'active' : '') }}">Withdrawals</a>
        --}}
        <a class="list-group-item list-group-item-action {{ (Route::is('profile.info') ? 'active' : '') }}" href="{{route('profile.info')}}">{{__('Profile')}}</a>
        <a href="{{url('/')}}/my_tickets"  class="list-group-item list-group-item-action {{ (Route::is('support') ? 'active' : '') }}">{{__('Support')}}</a>
        <a href="{{url('/')}}/my_vouchers"  class="list-group-item list-group-item-action {{ (Route::is('my_vouchers') ? 'active' : '') }}">{{__('Vouchers')}}</a>
        <a href="{{ route('mymerchants') }}" class="list-group-item list-group-item-action {{ (Route::is('mymerchants') ? 'active' : '') }}">{{__('Developers API')}}</a>
    </div>
    @endif
</div>