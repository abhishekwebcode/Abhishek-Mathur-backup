@if($withdrawal->Status->id == 1)
<button class="btn btn-sm btn-outline-success">{{$withdrawal->Status->name}}</button>
@elseif($withdrawal->Status->id == 2)
<button class="btn btn-sm btn-outline-danger">{{$withdrawal->Status->name}}</button>
@elseif($withdrawal->Status->id == 3)
<button class="btn btn-sm btn-outline-info">{{$withdrawal->Status->name}}</button>
@elseif($withdrawal->Status->id == 4)
<button class="btn btn-sm btn-outline-primary">{{$withdrawal->Status->name}}</button>
@endif