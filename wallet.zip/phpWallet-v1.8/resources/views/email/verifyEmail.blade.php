<p>Hello <strong>{{$user->name}}</strong>, please follow the link bellow to activate your <strong>{{setting('site.title')}}'s</strong>  account.</p>
<a href="{{url('/')}}/register/{{Auth::user()->email}}/{{Auth::user()->settings}}">Activation Link</a>
<br>
<p>
	Do not click the link if it's not you!
</p>
