@extends('layouts.app')

@section('content')
@include('partials.nav')
    <div class="row">
        @include('profile.partials.sidenav')
		
		<div class="col-lg-9 ">
          <h4 class="mb-3">{{__('Change Password')}}</h4>

          <form class="needs-validation" enctype="multipart/form-data" method="POST" action="{{route('profile.newpassword.store')}}">
          	{{csrf_field()}}
          	
            <div class="row">
              <div class="col-md-6 mb-3">
                <label for="newpassword">New password</label>
                <input type="password" class="form-control" id="newpassword" name="newpassword" placeholder="" value="" required="">
                @if ($errors->has('newpassword'))
                    <div class="invalid-feedback">
                        <strong>{{ $errors->first('newpassword') }}</strong>
                    </div>
                @endif
              </div>
              <div class="col-md-6 mb-3">
                <label for="newpasswordagain">Repeat your new password</label>
                <input type="password" class="form-control" id="newpasswordagain" name="newpasswordagain" placeholder="" value="" required="">
                @if ($errors->has('newpasswordagain'))
                    <div class="invalid-feedback">
                        <strong>{{ $errors->first('newpasswordagain') }}</strong>
                    </div>
                @endif
              </div>
            </div>

            <div class="mb-3">
              <label for="oldpassword">Old Password</label>
              <input type="password" class="form-control" id="oldpassword" name="oldpassword">
            </div>

            <hr class="mb-4">
            <button class="btn btn-primary btn-lg btn-block" type="submit">Save</button>
          </form>
        </div>

    </div>
@endsection

@section('footer')
	@include('partials.footer')
@endsection
