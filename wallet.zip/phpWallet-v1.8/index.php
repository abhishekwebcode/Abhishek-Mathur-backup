<?php
header('Location: https://pagador.scriptdemo.website/public')
?>