@extends('layouts.app')

@section('content')
	 <main class="mt-5 pt-4">
    <div class="container dark-grey-text mt-5">

      <!--Grid row-->
      <div class="row wow fadeIn">

        <!--Grid column-->
        <div class="col-md-6 mb-4">

          <?php $thumbnail = 'thumbnails/'.$product->thumbnail; ?>

          <img src="{{asset($thumbnail)}}" alt="">

        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-md-6 mb-4">

          <!--Content-->
          <div class="p-4">

            <div class="mb-3">
              <a href="">
                <span class="badge purple mr-1">{{$product->Categorie->name}}</span>
              </a>
              
            </div>

            <p class="lead">
              <span>{{$product->price}} {{setting('phpwallet.merchant_currency_symbol')}}</span>
            </p>

            <p class="lead font-weight-bold">Description</p>

            <p>{{$product->description}}</p>

            <form class="d-flex justify-content-left" method="post" action="{{url('/')}}/addtocart">
              <!-- Default input -->
              <input type="number" value="1" name="quantity" aria-label="Search" class="form-control" style="width: 100px">
              {{csrf_field()}}
              <input type="hidden" name="product_id" value="{{$product->id}}">
              <button class="btn btn-primary btn-md my-0 p" type="submit">Add to cart
                <i class="fa fa-shopping-cart ml-1"></i>
              </button>

            </form>

          </div>
          <!--Content-->

        </div>
        <!--Grid column-->

      </div>
      <!--Grid row-->

      <hr>
  {{--
      <!--Grid row-->
      <div class="row d-flex justify-content-center wow fadeIn">

        <!--Grid column-->
        <div class="col-md-6 text-center">

          <h4 class="my-4 h4">Additional information</h4>

          <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Natus suscipit modi sapiente illo soluta odit voluptates,
            quibusdam officia. Neque quibusdam quas a quis porro? Molestias illo neque eum in laborum.</p>

        </div>
        <!--Grid column-->

      </div>
      <!--Grid row-->
  --}}

   <!--Grid row-->
      <div class="row d-flex justify-content-center wow fadeIn">

        <!--Grid column-->
        <div class="col-md-6 text-center">

          <h4 class="my-4 h4">Related Products</h4>

          
        </div>
        <!--Grid column-->

      </div>
      <!--Grid row-->
      <!--Grid row-->
      <div class="row wow fadeIn">
        @foreach($related as $product)
          
          <?php

            $thumbnail = 'thumbnails/'.$product->thumbnail ;
          
          ?>
            
            <div class="col-lg-3 col-md-6 mb-4">

              <!--Card-->
              <div class="card">

                <!--Card image-->
                <div class="view overlay">
                  <img src="{{asset($thumbnail)}}" class="card-img-top" alt="">
                  <a href="{{url('/')}}/item/{{$product->title}}/{{$product->id}}">
                    <div class="mask rgba-white-slight"></div>
                  </a>
                </div>
                <!--Card image-->

                <!--Card content-->
                <div class="card-body text-center">
                  <!--Category & Title-->
                  <a href="" class="grey-text">
                    <h5>{{ $product->Categorie->name }}</h5>
                  </a>
                  <h5>
                    <strong>
                      <a href="" class="dark-grey-text">  {{ $product->title }}  
                        <span class="badge badge-pill danger-color">NEW</span>
                      </a>
                    </strong>
                  </h5>

                  <h4 class="font-weight-bold blue-text">
                    <strong>${{  $product->price }}</strong>
                  </h4>

                </div>
                <!--Card content-->

              </div>
              <!--Card-->

            </div>
            <!--Grid column-->
          
          @endforeach

      </div>
      <!--Grid row-->

    </div>
  </main>
@endsection