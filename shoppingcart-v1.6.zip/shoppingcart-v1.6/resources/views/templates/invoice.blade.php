@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
        		<div class="invoice-title">
        			<h2>Invoice</h2><h3 class="pull-right">Order # {{$invoice->id}}</h3>
        		</div>
        		<hr>
        		<div class="row">
        			<div class="col-xs-6">
        				<address>
        				<strong>Billed To:</strong><br>
        					John Smith<br>
        					1234 Main<br>
        					Apt. 4B<br>
        					Springfield, ST 54321
        				</address>
        			</div>
        			<div class="col-xs-6 text-right">
        				<address>
            			<strong>Shipped To:</strong><br>
        					Jane Smith<br>
        					1234 Main<br>
        					Apt. 4B<br>
        					Springfield, ST 54321
        				</address>
        			</div>
        		</div>
        		<div class="row">
        			<div class="col-xs-6">
        				<address>
        					<strong>Payment Method:</strong><br>
        					phpWallet<br>
        					{{Auth::user()->email}}
        				</address>
        			</div>
        			<div class="col-xs-6 text-right">
        				<address>
        					<strong>Order Date:</strong><br>
        					{{$invoice->created_at->diffForHumans()}}<br><br>
        				</address>
        			</div>
        		</div>
        	</div>
        </div>
        
        <div class="row">
        	<div class="col-md-12">
        		<div class="card panel-default">
        			<div class="card-header">
        				<h3 class="panel-title"><strong>Order summary</strong></h3>
        			</div>
        			<div class="card-body">
        				<div class="table-responsive">
        					<table class="table table-condensed">
        						<thead>
                                    <tr>
            							<td><strong>Item</strong></td>
            							<td class="text-center"><strong>Price</strong></td>
            							<td class="text-center"><strong>Quantity</strong></td>
            							<td class="text-right"><strong>Totals</strong></td>
                                    </tr>
        						</thead>
        						<tbody>
        							<!-- foreach ($order->lineItems as $line) or some such thing here -->
                                    @foreach($invoice->json_data->items as $item)

                                        <tr>
                                        <td> {{ $item->name }} </td>
                                        <td class="text-center"> ${{ $item->price }} </td>
                                        <td class="text-center"> {{ $item->qty }} </td>
                                        <td class="text-right"> ${{ ($item->price * $item->qty) }} </td>
                                    </tr>
                                    
                                    @endforeach
        							<tr>
        								<td class="thick-line"></td>
        								<td class="thick-line"></td>
        								<td class="thick-line text-center"><strong>Subtotal</strong></td>
        								<td class="thick-line text-right">${{$invoice->json_data->total}}</td>
        							</tr>
        							<tr>
        								<td class="border-0"></td>
        								<td class="border-0"></td>
        								<td class="border-0 text-center"><strong>Shipping</strong></td>
        								<td class="border-0 text-right">$0</td>
        							</tr>
        							<tr>
        								<td class="border-0"></td>
        								<td class="border-0"></td>
        								<td class="border-0 text-center"><strong>Total</strong></td>
        								<td class="border-0 text-right">${{$invoice->json_data->total}}</td>
        							</tr>
        						</tbody>
        					</table>
        				</div>
        			</div>
        		</div>
        	</div>
        </div>
    </div>
@endsection