@extends('layouts.app')

@section('content')
<div class="container">
    <div class="table-responsive">
    	<table class="table table-condensed">
    		<thead>
                <tr>
    				<td><strong>#</strong></td>
    				<td class="text-center"><strong>Order Id</strong></td>
    				<td class="text-center"><strong>Order date</strong></td>
                    <td class="text-center"><strong>Order status</strong></td>
    				<td class="text-right"><strong>Action</strong></td>
                </tr>
    		</thead>
    		<tbody>
    			<!-- foreach ($order->lineItems as $line) or some such thing here -->
                @forelse($invoices as $invoice)
                    <tr>
                        <td>{{$loop->iteration}} </td>
                        <td class="text-center"> {{ $invoice->id }}  </td>
                        <td class="text-center"> {{ $invoice->updated_at->diffForHumans() }}  </td>

                        <td class="text-center"> {{ ($invoice->is_paid)? 'paid' : 'waiting payment' }}  </td>
                        <td class="text-right"><a class="btn btn-primary" href="{{url('/')}}/invoice/{{$invoice->id}}">View order invoice</a></td>
                    </tr>
                @empty
                <div>
                    <h1>You don't have orders.</h1>
                </div>
                @endforelse
    		</tbody>
    	</table>
    </div>
</div>
@endsection