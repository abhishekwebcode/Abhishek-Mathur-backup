

<?php $__env->startSection('content'); ?>
	 <main class="mt-5 pt-4">
    <div class="container dark-grey-text mt-5">

      <!--Grid row-->
      <div class="row wow fadeIn">

        <!--Grid column-->
        <div class="col-md-6 mb-4">

          <?php $thumbnail = 'thumbnails/'.$product->thumbnail; ?>

          <img src="<?php echo e(asset($thumbnail)); ?>" alt="">

        </div>
        <!--Grid column-->

        <!--Grid column-->
        <div class="col-md-6 mb-4">

          <!--Content-->
          <div class="p-4">

            <div class="mb-3">
              <a href="">
                <span class="badge purple mr-1"><?php echo e($product->Categorie->name); ?></span>
              </a>
              
            </div>

            <p class="lead">
              <span><?php echo e($product->price); ?> <?php echo e(setting('phpwallet.merchant_currency_symbol')); ?></span>
            </p>

            <p class="lead font-weight-bold">Description</p>

            <p><?php echo e($product->description); ?></p>

            <form class="d-flex justify-content-left" method="post" action="<?php echo e(url('/')); ?>/addtocart">
              <!-- Default input -->
              <input type="number" value="1" name="quantity" aria-label="Search" class="form-control" style="width: 100px">
              <?php echo e(csrf_field()); ?>

              <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
              <button class="btn btn-primary btn-md my-0 p" type="submit">Add to cart
                <i class="fa fa-shopping-cart ml-1"></i>
              </button>

            </form>

          </div>
          <!--Content-->

        </div>
        <!--Grid column-->

      </div>
      <!--Grid row-->

      <hr>
  

   <!--Grid row-->
      <div class="row d-flex justify-content-center wow fadeIn">

        <!--Grid column-->
        <div class="col-md-6 text-center">

          <h4 class="my-4 h4">Related Products</h4>

          
        </div>
        <!--Grid column-->

      </div>
      <!--Grid row-->
      <!--Grid row-->
      <div class="row wow fadeIn">
        <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
          <?php

            $thumbnail = 'thumbnails/'.$product->thumbnail ;
          
          ?>
            
            <div class="col-lg-3 col-md-6 mb-4">

              <!--Card-->
              <div class="card">

                <!--Card image-->
                <div class="view overlay">
                  <img src="<?php echo e(asset($thumbnail)); ?>" class="card-img-top" alt="">
                  <a href="<?php echo e(url('/')); ?>/item/<?php echo e($product->title); ?>/<?php echo e($product->id); ?>">
                    <div class="mask rgba-white-slight"></div>
                  </a>
                </div>
                <!--Card image-->

                <!--Card content-->
                <div class="card-body text-center">
                  <!--Category & Title-->
                  <a href="" class="grey-text">
                    <h5><?php echo e($product->Categorie->name); ?></h5>
                  </a>
                  <h5>
                    <strong>
                      <a href="" class="dark-grey-text">  <?php echo e($product->title); ?>  
                        <span class="badge badge-pill danger-color">NEW</span>
                      </a>
                    </strong>
                  </h5>

                  <h4 class="font-weight-bold blue-text">
                    <strong>$<?php echo e($product->price); ?></strong>
                  </h4>

                </div>
                <!--Card content-->

              </div>
              <!--Card-->

            </div>
            <!--Grid column-->
          
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </div>
      <!--Grid row-->

    </div>
  </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>