

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="table-responsive">
    	<table class="table table-condensed">
    		<thead>
                <tr>
    				<td><strong>#</strong></td>
    				<td class="text-center"><strong>Order Id</strong></td>
    				<td class="text-center"><strong>Order date</strong></td>
                    <td class="text-center"><strong>Order status</strong></td>
    				<td class="text-right"><strong>Action</strong></td>
                </tr>
    		</thead>
    		<tbody>
    			<!-- foreach ($order->lineItems as $line) or some such thing here -->
                <?php $__empty_1 = true; $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?> </td>
                        <td class="text-center"> <?php echo e($invoice->id); ?>  </td>
                        <td class="text-center"> <?php echo e($invoice->updated_at->diffForHumans()); ?>  </td>

                        <td class="text-center"> <?php echo e(($invoice->is_paid)? 'paid' : 'waiting payment'); ?>  </td>
                        <td class="text-right"><a class="btn btn-primary" href="<?php echo e(url('/')); ?>/invoice/<?php echo e($invoice->id); ?>">View order invoice</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div>
                    <h1>You don't have orders.</h1>
                </div>
                <?php endif; ?>
    		</tbody>
    	</table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>