  <!-- Navbar -->
  <nav class="navbar fixed-top navbar-expand-lg navbar-light white scrolling-navbar">
    <div class="container">

      <!-- Brand -->
      <a class="navbar-brand  waves-effect" href="<?php echo e(url('/')); ?>">
                    <?php echo e(setting('site.title')); ?>

                </a>

      <!-- Collapse -->
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
        aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <!-- Links -->
      <div class="collapse navbar-collapse" id="navbarSupportedContent">

        <!-- Left -->
        <ul class="navbar-nav mr-auto">
          <li class="nav-item active">
          </li>
      	</ul>
       
        <!-- Right -->

        <ul class="navbar-nav nav-flex-icons">
        <?php if(auth()->guard()->guest()): ?>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a></li>
            <li class="nav-item"><a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a></li>
        <?php else: ?>
            <li class="nav-item">
				<a class="nav-link waves-effect" href="<?php echo e(url('/')); ?>/checkout">
          <?php if(!Cart::session(Auth::user()->id)->isEmpty()): ?>
					<span class="badge red z-depth-1 mr-1"> <?php echo e(Cart::getContent()->count()); ?> </span>
          <?php endif; ?>
					<i class="fa fa-shopping-cart"></i>
					<span class="clearfix d-none d-sm-inline-block">My Cart </span>
				</a>
			</li>
			
			<li  href="<?php echo e(url('/')); ?>"  class="nav-item ">
          <a  class="nav-link waves-effect" >
              Shop 
          </a>
      </li>
      <li class="nav-item ">
          <a href="<?php echo e(url('/')); ?>/orders"  class="nav-link waves-effect" >
              My Orders 
          </a>
      </li>
      <li class="nav-item">
       <a class="btn btn-primary nav-btn btn-xs" href="<?php echo e(route('logout')); ?>"
             onclick="event.preventDefault();
                           document.getElementById('logout-form').submit();">
              <?php echo e(__('Logout')); ?>

          </a>

          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
              <?php echo csrf_field(); ?>
          </form>
        </li>
        <?php endif; ?>
        </ul>

      </div>

    </div>
  </nav>
  <!-- Navbar -->