

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
        		<div class="invoice-title">
        			<h2>Invoice</h2><h3 class="pull-right">Order # <?php echo e($invoice->id); ?></h3>
        		</div>
        		<hr>
        		<div class="row">
        			<div class="col-xs-6">
        				<address>
        				<strong>Billed To:</strong><br>
        					John Smith<br>
        					1234 Main<br>
        					Apt. 4B<br>
        					Springfield, ST 54321
        				</address>
        			</div>
        			<div class="col-xs-6 text-right">
        				<address>
            			<strong>Shipped To:</strong><br>
        					Jane Smith<br>
        					1234 Main<br>
        					Apt. 4B<br>
        					Springfield, ST 54321
        				</address>
        			</div>
        		</div>
        		<div class="row">
        			<div class="col-xs-6">
        				<address>
        					<strong>Payment Method:</strong><br>
        					phpWallet<br>
        					<?php echo e(Auth::user()->email); ?>

        				</address>
        			</div>
        			<div class="col-xs-6 text-right">
        				<address>
        					<strong>Order Date:</strong><br>
        					<?php echo e($invoice->created_at->diffForHumans()); ?><br><br>
        				</address>
        			</div>
        		</div>
        	</div>
        </div>
        
        <div class="row">
        	<div class="col-md-12">
        		<div class="card panel-default">
        			<div class="card-header">
        				<h3 class="panel-title"><strong>Order summary</strong></h3>
        			</div>
        			<div class="card-body">
        				<div class="table-responsive">
        					<table class="table table-condensed">
        						<thead>
                                    <tr>
            							<td><strong>Item</strong></td>
            							<td class="text-center"><strong>Price</strong></td>
            							<td class="text-center"><strong>Quantity</strong></td>
            							<td class="text-right"><strong>Totals</strong></td>
                                    </tr>
        						</thead>
        						<tbody>
        							<!-- foreach ($order->lineItems as $line) or some such thing here -->
                                    <?php $__currentLoopData = $invoice->json_data->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                        <td> <?php echo e($item->name); ?> </td>
                                        <td class="text-center"> $<?php echo e($item->price); ?> </td>
                                        <td class="text-center"> <?php echo e($item->qty); ?> </td>
                                        <td class="text-right"> $<?php echo e(($item->price * $item->qty)); ?> </td>
                                    </tr>
                                    
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        							<tr>
        								<td class="thick-line"></td>
        								<td class="thick-line"></td>
        								<td class="thick-line text-center"><strong>Subtotal</strong></td>
        								<td class="thick-line text-right">$<?php echo e($invoice->json_data->total); ?></td>
        							</tr>
        							<tr>
        								<td class="border-0"></td>
        								<td class="border-0"></td>
        								<td class="border-0 text-center"><strong>Shipping</strong></td>
        								<td class="border-0 text-right">$0</td>
        							</tr>
        							<tr>
        								<td class="border-0"></td>
        								<td class="border-0"></td>
        								<td class="border-0 text-center"><strong>Total</strong></td>
        								<td class="border-0 text-right">$<?php echo e($invoice->json_data->total); ?></td>
        							</tr>
        						</tbody>
        					</table>
        				</div>
        			</div>
        		</div>
        	</div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>