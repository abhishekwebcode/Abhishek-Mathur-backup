<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
       
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $categories = \App\Categorie::all();
        $products = \App\Product::with('Categorie')->paginate(10);
        return view('home')
        ->with('products', $products)
        ->with('categories', $categories);
    }

    public function show_categorie($categorie_id, $name = null)
    {
        $categories = \App\Categorie::all();
        $products = \App\Product::with('Categorie')->where('categorie_id', $categorie_id)->paginate(10);
        return view('home')
        ->with('products', $products)
        ->with('categories', $categories);
    }
}
