<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
   protected $fillable = ['description','thumbnailurl','thumbnail','title','price','categorie_id'];

   public function Categorie(){
   	return $this->belongsTo(Categorie::class);
   }

  
}
